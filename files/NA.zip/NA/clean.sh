#!/bin/bash
if [ -f ./newton.out ]
then
	rm ./newton.out
fi 
if [ -f ./FixPoint.out ]
then
	rm ./FixPoint.out
fi 
echo "clean done"
exit 0
