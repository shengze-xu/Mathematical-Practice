#include "dig4.hpp"


double fixedpoint(double x)
{
    double A=sigdig(x*x);
    double B=sigdig(A+1);
    double C=sigdig(B/62.10);
    return -C;
}

int main()
{
    double x0=10;
    int n;
	printf("Enter iteration times :");
    scanf("%d",&n);
    x0=sigdig(x0);
    for(int i=0;i<n;i++)
    {
        x0=fixedpoint(x0);
    }
	double x1 = 1/x0;
    printf("%.4lf, %.2lf\n",x0,x1);
    return 0;
}
