#include "dig4.hpp"

double newton(double x)
{
    double A=sigdig(x);
    double B=sigdig(sigdig(sigdig(x+62.10)*x)+1);
    double C=sigdig(2*x)+62.10;
    double D=sigdig(B/C);
    return sigdig(x-D);
}
int main()
{
    double a;
	printf("Enter start point :");
    scanf("%lf",&a);
    a=sigdig(a);
    for(int i=0;i<10;i++)
    {
        a=newton(a);
    }
	double b = 1/a;
    printf("%.4lf %.2lf\n",a,b);
    return 0;
}
