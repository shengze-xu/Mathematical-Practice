#!/bin/bash
if [ ! -f ./newton.out ]
then
	gcc -w newton.cpp -o newton.out 
fi 
if [ ! -f ./FixPoint.out ]
then
	gcc -w FixPoint.cpp -o FixPoint.out 
fi 
echo "compile done"
exit 0
