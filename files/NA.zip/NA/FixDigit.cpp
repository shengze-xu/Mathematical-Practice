//
//  FixDigit.cpp
//  NA
//  Compile with g++
//  Created by Adam Wu on 2020/9/20.
//  Copyright © 2020 Adam Wu. All rights reserved.
//

#include <iostream>
using namespace std;

class FDFloat{
private:
    int digit = 4;
    int exp = 0;
    int val = 0;
    
public:
    FDFloat(double x){
        string s = to_string(x);
        s.erase(remove(s.begin(),s.end(),'.'), s.end());
        bool negetive = false;
        if (x<0)negetive = true;
        x = abs(x);
        exp = 0;
        if (x<1){
            while(x<1){
                x*=10;
                exp--;
            }
        }else{
            while(x>1){
                x/=10;
                exp++;
            }
        }
        
        for (int i=0; i<digit; i++){
            val *= 10;
            val += s[i] -'0';
        }
        if (s[digit]-'0'>4)val++;
        if (negetive) val = -val;
    };
    double ToDouble()const {
        return  this->val*pow(10, this->exp-this->digit);
    }
    
    void echo(){
        double i = this->ToDouble();
        cout<<i<<endl;
    }
    
    friend FDFloat operator+(const FDFloat& l, const FDFloat& r){
        double i1 = l.ToDouble();
        double i2 = r.ToDouble();
        return FDFloat(i1+i2);
    };
    friend FDFloat operator*(const FDFloat& l, const FDFloat& r){
        double i1 = l.ToDouble();
        double i2 = r.ToDouble();
        return FDFloat(i1*i2);
    };
    friend FDFloat operator-(const FDFloat& l, const FDFloat& r){
        double i1 = l.ToDouble();
        double i2 = r.ToDouble();
        return FDFloat(i1-i2);
    };
    friend FDFloat operator/(const FDFloat& l, const FDFloat& r){
        double i1 = l.val*pow(10, r.exp);
        double i2 = r.ToDouble();
        return FDFloat(i1/i2);
    };
    
};

int main(){
    FDFloat a(1.535);
    FDFloat b(35);
    FDFloat c = a*b;
    c.echo();
    double f = 1.535*35;
    cout << f << endl;
    
}
