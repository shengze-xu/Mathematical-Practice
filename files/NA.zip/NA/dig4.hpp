#include<stdio.h>
#include<math.h>
#define Precise 4
double sigdig(double value)
{
    int sign=0;
    int power=0;
    if(value==0) return 0.;
    if(value<0)
    {
        sign=1;
        value=-value;
    }
    while(value<1||value>=10)
    {
        if(value>=10)
        {
            value/=10;
            power++;
        }
        if(value<1)
        {
            value*=10;
            power--;
        }
    }
    return (double)((int)(value*pow(10,Precise-1)))*pow(10,power-3)*pow(-1,sign);
}
